module.exports = Marionette.ItemView.extend( {
	template: '#tmpl-elementor-panel-history-no-items',
	id: 'elementor-panel-history-no-items',
	className: 'elementor-panel-nerd-box'
} );
