<?php
//echo "TESTING";
echo TMM_Ext_Sliders::draw_sliders_options();