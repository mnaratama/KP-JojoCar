<?php if (!defined('ABSPATH')) die('No direct access allowed'); ?>
<div class="tmk_row">
    <br />
    <table>
        <tr>
            <td>
				<label class="sel">
					<?php echo $select ?>
				</label>
            </td>
            <td style="vertical-align: top !important;">
                <a class="remove-button remove_seo_group_category" href="#"></a>
            </td>
        </tr>
    </table>
</div>
