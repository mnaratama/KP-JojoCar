<?php if (!defined('ABSPATH')) exit(); ?>
<?php get_header(); ?>
<?php get_template_part('content', 'header'); ?>
<?php get_template_part('content', null); ?>
<?php get_template_part('content', 'pagenavi'); ?>
<?php get_footer(); ?>